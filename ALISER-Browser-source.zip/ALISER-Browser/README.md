# ALISER Browser

Android browser starter project using Kotlin, Jetpack Compose and Mozilla GeckoView.

## Included
- GeckoView web engine
- Dark ALISER interface
- Address bar and DuckDuckGo search
- Multiple tabs
- Local bookmarks and history
- GeckoView anti-tracking protection
- No app-owned analytics or telemetry SDK

## Build APK with GitHub Actions using this ZIP
1. Create or open a GitHub repository.
2. Upload this file named exactly `ALISER-Browser-source.zip` to the repository root and commit it.
3. Open the repository's **Actions** tab.
4. Select **Build ALISER APK**. A push also triggers the workflow automatically.
5. Open the completed run and download `ALISER-Browser-debug`.
6. Extract that downloaded artifact ZIP and install `app-debug.apk`.

The workflow can also build if you extract this project's files directly into the repository root.

## Important
This is an initial prototype, not a finished production browser. It must pass a real GitHub Actions build and device testing before it can be called ready. GeckoView tracking protection is enabled, but it does not guarantee that every advertisement is blocked. The current project does not yet include a custom Rust native module, extension support, password sync, or a downloads manager. The APK produced by this workflow is a debug build for testing, not a Play Store release.
